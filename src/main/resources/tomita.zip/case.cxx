﻿#encoding "utf-8"
#GRAMMAR_ROOT S
S -> Case interp(Case.name);
Case -> Prep* Word<gram='A'>* Init Action Word<gram='A'>* Word*;
Case -> Prep* Init Action Word<gram='A'>* Noun* Word* Action Word*;
Case -> Prep* Word<gram='A'>* Noun<gram='dat'>* Init Action Word<gram='A'>* Noun* Word* Action Word*;
Case -> Prep* Word<gram='APRO'> Noun Init Action Word<gram='A'>* Word*;

Case -> Prep Word* Init Action Word*;

Case -> Prep* Noun* Init Prep* Spec Init Action Word<gram='A'>* Word*;
Case -> Prep* Action Noun* Action Prep* Word<gram='A'>* Init Prep* Noun*;
Case -> Prep* Noun+ Action Prep* Word<gram='A'>* Init Prep* Noun*;

Case -> Word<gram='CONJ'> Word<gram='partcp'> Init Prep Init Action AnyWord* Comma AnyWord* Action;
Case -> Word<gram='CONJ'> Word<gram='partcp'> Init Word<gram='PART'> Init Action AnyWord* Comma AnyWord* Action;

Case -> SpecAction Prep* Noun* Prep* Init Word*;
Case -> Word<gram='A'>* Noun+ SpecAction Prep* Noun* Prep* Init Word*;
Case -> SpecAction Prep* Noun* Prep* Word* Init Word*;
Case -> Word<gram='A'>* Noun+ SpecAction Prep* Noun* Prep* Word* Init Word*;

Case -> Prep* Word<gram='A'>* Spec+ Action Word*;
Case -> Prep* Word<gram='A'>* Noun* Spec+ Action Word*;
Case -> Prep* Word<gram='A'>* Noun* Spec+ Action Word* Action Word*;
Case -> Prep* Action Word* Spec+ Word*;
Case -> Prep* Spec Word<gram='A'>* Noun* Word<gram='A'>* Spec Word* Action Word*;

Case -> Action Init Word;

Action -> Word<gram='PART'>* Word<gram='praed'>* Verb;
Action -> Word<gram='PART'>* Word<gram='A,brev'> Word<gram='inf'> Word<gram='APRO'>*;
Action -> Comma Word<gram='PART'>* Word<gram='praed'>* Word<gram='ger'>;
Action -> Comma Word<gram='PART'>* Word<gram='praed'>* Word<gram='partcp'>;
Action -> Comma Word<gram='PART'>* Word<gram='praed'>* Word<gram='partcp'> Word<gram='inf'>;

Init -> Word<kwtype='инициатор', h-reg1> | Word<kwtype='инициатор', h-reg2> | Word<kwtype='инициатор', l-reg>;
Spec -> Word<kwtype='спец_слова', h-reg1> | Word<kwtype='спец_слова', h-reg2> | Word<kwtype='спец_слова', l-reg>;
SpecAction -> Word<kwtype='спец_действия', h-reg1> | Word<kwtype='спец_действия', h-reg2> | Word<kwtype='спец_действия', l-reg>;