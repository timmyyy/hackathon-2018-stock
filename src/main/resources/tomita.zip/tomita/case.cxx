﻿#encoding "utf-8"
#GRAMMAR_ROOT S
S -> Case;

Case -> SCase;
Case -> SubCase;

Case -> Prep+ Word<gram='род'>+ interp(Target.action) Prep* Subject;
Case -> Prep+ Word<gram='род'>+ interp(Target.action) Prep* Obj Subject;

Case -> System SystemSubject;
Case -> Subsystem SubsystemSubject;

SCase -> System SystemSubject;
SubCase -> Subsystem SubsystemSubject;

InfCase -> Word<gram='inf'>+ interp(Target.action) Prep* Subject;
InfCase -> Word<gram='inf'>+ interp(Target.action) Prep* Obj Subject;

SystemSubject -> UnknownPOS interp(Target.system);
SystemSubject -> Noun interp(Target.system);
SystemSubject -> Noun Noun interp(Target.system);
SystemSubject -> Word interp(Target.system);

SubsystemSubject -> UnknownPOS interp(Target.subsystem);
SubsystemSubject -> Noun interp(Target.subsystem);
SubsystemSubject -> Noun Noun interp(Target.subsystem);
SubsystemSubject -> Word interp(Target.subsystem);

Subject -> UnknownPOS interp(Target.keywords);
Subject -> Noun interp(Target.keywords);
Subject -> Noun Noun interp(Target.keywords);
Subject -> Word interp(Target.keywords);

Obj -> Word<gram='вин'> | Word<gram='твор'>;
System -> Word<kwtype='обозначение_системы', h-reg1> | Word<kwtype='обозначение_системы', h-reg2> | Word<kwtype='обозначение_системы', l-reg>;
Subsystem -> Word<kwtype='обозначение_подсистемы', h-reg1> | Word<kwtype='обозначение_подсистемы', h-reg2> | Word<kwtype='обозначение_подсистемы', l-reg>;